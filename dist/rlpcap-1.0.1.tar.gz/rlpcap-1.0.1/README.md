# rlpcap

Rocket League UDP sniffer utilities.

## install

`pip install rlpcap` (after it is uploaded to PyPI)

## usage

Run `rlpcap` (console script) or import `rlpcap.sniffer.sniff_for_server()`.

Note: packet capture requires elevated privileges and Npcap/WinPcap on Windows.
